def valid_ipv4?(ip)
  #Розділяємо рядок на октети
  octets = ip.split(".")

  #Перевірити, чи є рівно 4 октети
  return false unless octets.length == 4

  #Перевіряємо кожен октет
  octets.each do |octet|
    #Перевіряємо, чи є октет цілим числом
    return false unless octet.match?(/^\d+$/)

    #Перевіряємо, чи лежить октет в діапазоні 0-255
    octet_value = octet.to_i
    return false unless octet_value >= 0 && octet_value <= 255

    #Перевіряємо, чи немає ведучих нулів
    return false unless octet == octet.to_i.to_s
  end

  #Якщо всі перевірки успішно пройдені, повернути true
  return true
end

puts valid_ipv4?("192.168.1.1")
puts valid_ipv4?("0.0.0.0")
puts valid_ipv4?("256.1.1.1")

